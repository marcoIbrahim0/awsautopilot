AWS Security Autopilot — Group action artifact

Action: S3 general purpose buckets should block public read access
Action ID: d03ad604-a057-4677-8c12-0934a27317ea
Tier: executable
Tier root: executable/actions
Outcome: executable_bundle_generated
Strategy: s3_migrate_cloudfront_oac_private
Profile: s3_migrate_cloudfront_oac_private

Decision summary: Family resolver kept executable S3.2 profile 's3_migrate_cloudfront_oac_private' for strategy 's3_migrate_cloudfront_oac_private'. Run creation did not require additional risk-only acceptance.
Runnable Terraform is present in this folder.
