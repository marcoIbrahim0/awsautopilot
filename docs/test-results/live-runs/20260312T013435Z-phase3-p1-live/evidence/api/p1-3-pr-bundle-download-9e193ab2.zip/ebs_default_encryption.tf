# EBS default encryption - Action: 0ca64b94-9dcb-4a97-91b0-27b0341865bc
resource "aws_ebs_encryption_by_default" "security_autopilot" {
  enabled = true
}

