Evidence Pack — AWS Security Autopilot
Generated: 2026-03-01T01:11:28.808221+00:00
Export ID: 9fd34942-be37-4149-be00-d80d7e9f2f27
Tenant ID: 19b8d7c6-0100-421a-a084-c8b06d466837

This zip contains:
- manifest.json    — Export metadata and file list
- findings.csv     — Security Hub findings
- actions.csv      — Deduplicated actions
- remediation_runs.csv — Remediation run history
- exceptions.csv   — Exceptions/suppressions with expiry

Control IDs (findings and actions):
The control_id field in findings and actions corresponds to Security Hub control IDs (e.g. CIS AWS Foundations Benchmark, AWS Foundational Security Best Practices). Use these IDs to map evidence to your compliance framework (e.g. SOC 2, ISO 27001).

All timestamps are ISO 8601 (UTC). CSV files use UTF-8 encoding.
