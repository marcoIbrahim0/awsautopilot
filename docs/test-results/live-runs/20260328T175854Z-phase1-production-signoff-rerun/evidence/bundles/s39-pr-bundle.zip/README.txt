AWS Security Autopilot — Terraform bundle

Credentials and region
--------------------
- Use your normal AWS credentials: a named profile from ~/.aws/config (e.g. default) or environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY).
- Do NOT set AWS_PROFILE to your account ID. Use a profile name (e.g. default) or leave unset to use the default profile.
- Set the region: export AWS_REGION=eu-north-1 (or your action's region).

Commands
--------
terraform init
terraform plan
terraform apply

Terraform proof metadata (C2/C5)
-------------------------------
- terraform_plan_timestamp_utc: 2026-03-28T18:02:49+00:00
- preserved_configuration_statement: The generated IaC is scoped to this control and is expected to preserve unrelated existing configuration unless a generated diff explicitly changes it.


Selected strategy
-----------------
- strategy_id: s3_enable_access_logging_guided

Risk recommendation
-------------------
- safe_to_proceed

Dependency review checklist
---------------------------
- [pass] s3_access_logging_bucket_scope_confirmed: Bucket-scoped target was identified for S3 access logging. This action can stay executable once destination safety is proven.
- [pass] s3_access_logging_destination_safety_proven: Destination safety is proven for the selected S3 access-log bucket.
