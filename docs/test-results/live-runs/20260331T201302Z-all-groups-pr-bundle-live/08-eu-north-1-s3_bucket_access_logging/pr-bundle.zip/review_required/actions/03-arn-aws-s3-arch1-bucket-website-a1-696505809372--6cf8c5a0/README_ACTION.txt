AWS Security Autopilot — Group action artifact

Action: S3 bucket access logging enabled
Action ID: 6cf8c5a0-d031-40e5-b254-2f4eb08a9f5d
Tier: review_required
Tier root: review_required/actions
Outcome: review_required_metadata_only
Strategy: s3_enable_access_logging_guided
Profile: s3_enable_access_logging_review_destination_safety

Decision summary: Family resolver downgraded S3.9 to destination-safety review. Destination log bucket '{{source_bucket}}-access-logs' could not be verified from this account context (ParamValidationError). Run creation did not require additional risk-only acceptance.
This folder is metadata only and does not contain runnable Terraform.
