AWS Security Autopilot — Group action artifact

Action: S3 general purpose buckets should have server access logging enabled
Action ID: 1f3adb89-5325-439b-8675-fece9afef0ef
Tier: review_required
Tier root: review_required/actions
Outcome: review_required_metadata_only
Strategy: s3_enable_access_logging_guided
Profile: s3_enable_access_logging_review_destination_safety

Decision summary: Family resolver downgraded S3.9 to destination-safety review. Destination log bucket '{{source_bucket}}-access-logs' could not be verified from this account context (ParamValidationError). Run creation did not require additional risk-only acceptance.
This folder is metadata only and does not contain runnable Terraform.
