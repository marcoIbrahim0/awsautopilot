# Enforce SSL-only S3 requests - Action: 4fc6db43-ea06-4afc-a670-2ca8d0495070
locals {
  target_bucket_name = "ocypheris-live-ct-20260323162333-eu-north-1"
}

variable "existing_bucket_policy_json" {
  type        = string
  default     = ""
  description = "Optional existing bucket policy JSON for merge-safe preservation."
}

variable "exempt_principal_arns" {
  type        = list(string)
  default     = []
  description = "Optional IAM principal ARNs exempted from strict SSL deny."
}

data "aws_iam_policy_document" "required_ssl" {
  statement {
    sid    = "DenyInsecureTransport"
    effect = "Deny"
    principals {
      type        = "*"
      identifiers = ["*"]
    }
    actions = ["s3:*"]
    resources = [
      "arn:aws:s3:::${local.target_bucket_name}",
      "arn:aws:s3:::${local.target_bucket_name}/*",
    ]
    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }

  dynamic "statement" {
    for_each = length(var.exempt_principal_arns) == 0 ? [] : [var.exempt_principal_arns]
    content {
      sid    = "AllowExemptPrincipals"
      effect = "Allow"
      principals {
        type        = "AWS"
        identifiers = statement.value
      }
      actions = ["s3:*"]
      resources = [
        "arn:aws:s3:::${local.target_bucket_name}",
        "arn:aws:s3:::${local.target_bucket_name}/*",
      ]
    }
  }
}

data "aws_iam_policy_document" "merged_policy" {
  source_policy_documents   = var.existing_bucket_policy_json == "" ? [] : [var.existing_bucket_policy_json]
  override_policy_documents = [data.aws_iam_policy_document.required_ssl.json]
}

resource "aws_s3_bucket_policy" "security_autopilot" {
  bucket = local.target_bucket_name
  policy = data.aws_iam_policy_document.merged_policy.json
}
