#!/usr/bin/env bash
set +e

REPORT_URL=https://api.ocypheris.com/api/internal/group-runs/report
REPORT_TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiI5Zjc2MTZkOC1hZjA0LTQzY2EtOTljZC03MTM2MjUzNTdiNzAiLCJncm91cF9ydW5faWQiOiIwNWI5YTY2Yi05ZmY0LTQ3NGQtOTQ2YS05YjRhNmNiZDgxYTIiLCJncm91cF9pZCI6IjZlNDU3NWU0LTFmZGQtNDE2MC1hNmRmLWE3M2U5MmJiNjEzZiIsImFsbG93ZWRfYWN0aW9uX2lkcyI6WyIyNmI2ZjAzNy05YTU1LTQxZjQtOWZkOS03YjQ5YjE2NWFiNWYiLCIyN2IwM2IwOC1mNTBjLTQzODMtYWVmYy1mMjkxYWFmODM1OWIiLCIyYTc0ZTQ0Ny1lNzcwLTQ4ZWQtOTAyZi0wMWMzZGU2ZTAwNzQiLCIyYWE4MTk0MS04MDUzLTQ2NDMtODk3ZS05N2NjODNjODE0ZTIiLCI1NjEyMjIzZi1lNGE2LTQ0OWYtYThmMC0xMGFkMzU3YzQxMmYiLCI1NmFiOWUzMi1mZjE4LTQ2NmMtYTU3Mi1kOTUxZGIxYTM5MDAiLCI2YmZkYmM3Yi0xYTU0LTRiYjEtYjM2Ni1hYjk5ZWU1OWE2NzciLCI5NmQyZTUzYi1lZWEwLTQ3NmUtYTczYi1jZGZkNGMwYzM2ZmUiLCJjY2U1ZTNjNC0xODc2LTQzMDItYjQ0NC1kMzBiZDdmN2NkOGMiLCJjZWY5MWMxNS04MDBkLTRkMWQtOWEyNS1mOTYxYTA4Nzc5ZDMiLCJkOWU5YjQ3Zi0zNjIyLTQ3MjUtYWIyMC01MzI0YzllNTYwYzciXSwianRpIjoiZDFmMTNiYTctOTM5ZC00NWMwLTlmZmMtNzZkNjU2ZGE5ZTJmIiwiaWF0IjoxNzc0MjIyNTQzLCJleHAiOjE3NzQzMDg5NDN9.3YE8yf9zOz_VvfAqttotESa9u_ZELgrZpEv7l78DvFM
STARTED_TEMPLATE='{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiI5Zjc2MTZkOC1hZjA0LTQzY2EtOTljZC03MTM2MjUzNTdiNzAiLCJncm91cF9ydW5faWQiOiIwNWI5YTY2Yi05ZmY0LTQ3NGQtOTQ2YS05YjRhNmNiZDgxYTIiLCJncm91cF9pZCI6IjZlNDU3NWU0LTFmZGQtNDE2MC1hNmRmLWE3M2U5MmJiNjEzZiIsImFsbG93ZWRfYWN0aW9uX2lkcyI6WyIyNmI2ZjAzNy05YTU1LTQxZjQtOWZkOS03YjQ5YjE2NWFiNWYiLCIyN2IwM2IwOC1mNTBjLTQzODMtYWVmYy1mMjkxYWFmODM1OWIiLCIyYTc0ZTQ0Ny1lNzcwLTQ4ZWQtOTAyZi0wMWMzZGU2ZTAwNzQiLCIyYWE4MTk0MS04MDUzLTQ2NDMtODk3ZS05N2NjODNjODE0ZTIiLCI1NjEyMjIzZi1lNGE2LTQ0OWYtYThmMC0xMGFkMzU3YzQxMmYiLCI1NmFiOWUzMi1mZjE4LTQ2NmMtYTU3Mi1kOTUxZGIxYTM5MDAiLCI2YmZkYmM3Yi0xYTU0LTRiYjEtYjM2Ni1hYjk5ZWU1OWE2NzciLCI5NmQyZTUzYi1lZWEwLTQ3NmUtYTczYi1jZGZkNGMwYzM2ZmUiLCJjY2U1ZTNjNC0xODc2LTQzMDItYjQ0NC1kMzBiZDdmN2NkOGMiLCJjZWY5MWMxNS04MDBkLTRkMWQtOWEyNS1mOTYxYTA4Nzc5ZDMiLCJkOWU5YjQ3Zi0zNjIyLTQ3MjUtYWIyMC01MzI0YzllNTYwYzciXSwianRpIjoiZDFmMTNiYTctOTM5ZC00NWMwLTlmZmMtNzZkNjU2ZGE5ZTJmIiwiaWF0IjoxNzc0MjIyNTQzLCJleHAiOjE3NzQzMDg5NDN9.3YE8yf9zOz_VvfAqttotESa9u_ZELgrZpEv7l78DvFM","event":"started","reporting_source":"bundle_callback"}'
FINISHED_SUCCESS_TEMPLATE='{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiI5Zjc2MTZkOC1hZjA0LTQzY2EtOTljZC03MTM2MjUzNTdiNzAiLCJncm91cF9ydW5faWQiOiIwNWI5YTY2Yi05ZmY0LTQ3NGQtOTQ2YS05YjRhNmNiZDgxYTIiLCJncm91cF9pZCI6IjZlNDU3NWU0LTFmZGQtNDE2MC1hNmRmLWE3M2U5MmJiNjEzZiIsImFsbG93ZWRfYWN0aW9uX2lkcyI6WyIyNmI2ZjAzNy05YTU1LTQxZjQtOWZkOS03YjQ5YjE2NWFiNWYiLCIyN2IwM2IwOC1mNTBjLTQzODMtYWVmYy1mMjkxYWFmODM1OWIiLCIyYTc0ZTQ0Ny1lNzcwLTQ4ZWQtOTAyZi0wMWMzZGU2ZTAwNzQiLCIyYWE4MTk0MS04MDUzLTQ2NDMtODk3ZS05N2NjODNjODE0ZTIiLCI1NjEyMjIzZi1lNGE2LTQ0OWYtYThmMC0xMGFkMzU3YzQxMmYiLCI1NmFiOWUzMi1mZjE4LTQ2NmMtYTU3Mi1kOTUxZGIxYTM5MDAiLCI2YmZkYmM3Yi0xYTU0LTRiYjEtYjM2Ni1hYjk5ZWU1OWE2NzciLCI5NmQyZTUzYi1lZWEwLTQ3NmUtYTczYi1jZGZkNGMwYzM2ZmUiLCJjY2U1ZTNjNC0xODc2LTQzMDItYjQ0NC1kMzBiZDdmN2NkOGMiLCJjZWY5MWMxNS04MDBkLTRkMWQtOWEyNS1mOTYxYTA4Nzc5ZDMiLCJkOWU5YjQ3Zi0zNjIyLTQ3MjUtYWIyMC01MzI0YzllNTYwYzciXSwianRpIjoiZDFmMTNiYTctOTM5ZC00NWMwLTlmZmMtNzZkNjU2ZGE5ZTJmIiwiaWF0IjoxNzc0MjIyNTQzLCJleHAiOjE3NzQzMDg5NDN9.3YE8yf9zOz_VvfAqttotESa9u_ZELgrZpEv7l78DvFM","event":"finished","reporting_source":"bundle_callback","action_results":[{"action_id":"26b6f037-9a55-41f4-9fd9-7b49b165ab5f","execution_status":"success"},{"action_id":"27b03b08-f50c-4383-aefc-f291aaf8359b","execution_status":"success"},{"action_id":"2a74e447-e770-48ed-902f-01c3de6e0074","execution_status":"success"},{"action_id":"2aa81941-8053-4643-897e-97cc83c814e2","execution_status":"success"},{"action_id":"5612223f-e4a6-449f-a8f0-10ad357c412f","execution_status":"success"},{"action_id":"56ab9e32-ff18-466c-a572-d951db1a3900","execution_status":"success"},{"action_id":"6bfdbc7b-1a54-4bb1-b366-ab99ee59a677","execution_status":"success"},{"action_id":"96d2e53b-eea0-476e-a73b-cdfd4c0c36fe","execution_status":"success"},{"action_id":"cce5e3c4-1876-4302-b444-d30bd7f7cd8c","execution_status":"success"},{"action_id":"cef91c15-800d-4d1d-9a25-f961a08779d3","execution_status":"success"},{"action_id":"d9e9b47f-3622-4725-ab20-5324c9e560c7","execution_status":"success"}]}'
FINISHED_FAILED_TEMPLATE='{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiI5Zjc2MTZkOC1hZjA0LTQzY2EtOTljZC03MTM2MjUzNTdiNzAiLCJncm91cF9ydW5faWQiOiIwNWI5YTY2Yi05ZmY0LTQ3NGQtOTQ2YS05YjRhNmNiZDgxYTIiLCJncm91cF9pZCI6IjZlNDU3NWU0LTFmZGQtNDE2MC1hNmRmLWE3M2U5MmJiNjEzZiIsImFsbG93ZWRfYWN0aW9uX2lkcyI6WyIyNmI2ZjAzNy05YTU1LTQxZjQtOWZkOS03YjQ5YjE2NWFiNWYiLCIyN2IwM2IwOC1mNTBjLTQzODMtYWVmYy1mMjkxYWFmODM1OWIiLCIyYTc0ZTQ0Ny1lNzcwLTQ4ZWQtOTAyZi0wMWMzZGU2ZTAwNzQiLCIyYWE4MTk0MS04MDUzLTQ2NDMtODk3ZS05N2NjODNjODE0ZTIiLCI1NjEyMjIzZi1lNGE2LTQ0OWYtYThmMC0xMGFkMzU3YzQxMmYiLCI1NmFiOWUzMi1mZjE4LTQ2NmMtYTU3Mi1kOTUxZGIxYTM5MDAiLCI2YmZkYmM3Yi0xYTU0LTRiYjEtYjM2Ni1hYjk5ZWU1OWE2NzciLCI5NmQyZTUzYi1lZWEwLTQ3NmUtYTczYi1jZGZkNGMwYzM2ZmUiLCJjY2U1ZTNjNC0xODc2LTQzMDItYjQ0NC1kMzBiZDdmN2NkOGMiLCJjZWY5MWMxNS04MDBkLTRkMWQtOWEyNS1mOTYxYTA4Nzc5ZDMiLCJkOWU5YjQ3Zi0zNjIyLTQ3MjUtYWIyMC01MzI0YzllNTYwYzciXSwianRpIjoiZDFmMTNiYTctOTM5ZC00NWMwLTlmZmMtNzZkNjU2ZGE5ZTJmIiwiaWF0IjoxNzc0MjIyNTQzLCJleHAiOjE3NzQzMDg5NDN9.3YE8yf9zOz_VvfAqttotESa9u_ZELgrZpEv7l78DvFM","event":"finished","reporting_source":"bundle_callback","action_results":[{"action_id":"26b6f037-9a55-41f4-9fd9-7b49b165ab5f","execution_status":"failed","execution_error_code":"bundle_runner_failed","execution_error_message":"run_actions.sh exited non-zero"},{"action_id":"27b03b08-f50c-4383-aefc-f291aaf8359b","execution_status":"failed","execution_error_code":"bundle_runner_failed","execution_error_message":"run_actions.sh exited non-zero"},{"action_id":"2a74e447-e770-48ed-902f-01c3de6e0074","execution_status":"failed","execution_error_code":"bundle_runner_failed","execution_error_message":"run_actions.sh exited non-zero"},{"action_id":"2aa81941-8053-4643-897e-97cc83c814e2","execution_status":"failed","execution_error_code":"bundle_runner_failed","execution_error_message":"run_actions.sh exited non-zero"},{"action_id":"5612223f-e4a6-449f-a8f0-10ad357c412f","execution_status":"failed","execution_error_code":"bundle_runner_failed","execution_error_message":"run_actions.sh exited non-zero"},{"action_id":"56ab9e32-ff18-466c-a572-d951db1a3900","execution_status":"failed","execution_error_code":"bundle_runner_failed","execution_error_message":"run_actions.sh exited non-zero"},{"action_id":"6bfdbc7b-1a54-4bb1-b366-ab99ee59a677","execution_status":"failed","execution_error_code":"bundle_runner_failed","execution_error_message":"run_actions.sh exited non-zero"},{"action_id":"96d2e53b-eea0-476e-a73b-cdfd4c0c36fe","execution_status":"failed","execution_error_code":"bundle_runner_failed","execution_error_message":"run_actions.sh exited non-zero"},{"action_id":"cce5e3c4-1876-4302-b444-d30bd7f7cd8c","execution_status":"failed","execution_error_code":"bundle_runner_failed","execution_error_message":"run_actions.sh exited non-zero"},{"action_id":"cef91c15-800d-4d1d-9a25-f961a08779d3","execution_status":"failed","execution_error_code":"bundle_runner_failed","execution_error_message":"run_actions.sh exited non-zero"},{"action_id":"d9e9b47f-3622-4725-ab20-5324c9e560c7","execution_status":"failed","execution_error_code":"bundle_runner_failed","execution_error_message":"run_actions.sh exited non-zero"}]}'
REPLAY_DIR="./.bundle-callback-replay"
RUNNER="./run_actions.sh"

mkdir -p "$REPLAY_DIR"

iso_now() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

inject_timestamp() {
  local template_json="$1"
  local field_name="$2"
  local field_value="$3"
  python3 - "$template_json" "$field_name" "$field_value" <<'PY'
import json
import sys

payload = json.loads(sys.argv[1])
payload[str(sys.argv[2])] = str(sys.argv[3])
print(json.dumps(payload, separators=(",", ":")))
PY
}

post_payload() {
  local payload="$1"
  if [ -z "$REPORT_URL" ] || [ -z "$REPORT_TOKEN" ]; then
    return 1
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -sS -X POST "$REPORT_URL" -H "Content-Type: application/json" -d "$payload" >/dev/null 2>&1
    return $?
  fi
  return 1
}

persist_replay() {
  local suffix="$1"
  local payload="$2"
  local file="$REPLAY_DIR/${suffix}-$(date +%s).json"
  printf '%s\n' "$payload" > "$file"
}

STARTED_AT="$(iso_now)"
START_PAYLOAD="$(inject_timestamp "$STARTED_TEMPLATE" "started_at" "$STARTED_AT")"
if ! post_payload "$START_PAYLOAD"; then
  persist_replay "started" "$START_PAYLOAD"
fi

chmod +x "$RUNNER"
"$RUNNER"
RUN_RC=$?

FINISHED_AT="$(iso_now)"
if [ "$RUN_RC" -eq 0 ]; then
  FINISH_PAYLOAD="$(inject_timestamp "$FINISHED_SUCCESS_TEMPLATE" "finished_at" "$FINISHED_AT")"
else
  FINISH_PAYLOAD="$(inject_timestamp "$FINISHED_FAILED_TEMPLATE" "finished_at" "$FINISHED_AT")"
fi

if ! post_payload "$FINISH_PAYLOAD"; then
  persist_replay "finished" "$FINISH_PAYLOAD"
fi

exit "$RUN_RC"
