#!/usr/bin/env bash
set +e

REPORT_URL=http://localhost:8000/api/internal/group-runs/report
REPORT_TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiJjMzM1MWEwMi0wYmMyLTQ0NDktYmVlZC1kNTlkN2FjOTM3ZDAiLCJncm91cF9ydW5faWQiOiI4MDA4MTQ1My01ZWVjLTRjNjQtODYyOC04ZWRhNDMwZTlhYzEiLCJncm91cF9pZCI6ImFhMDg3ZDlhLTA1NDctNGQ3Ni1iZDUxLWY0ZWViMDAwNWU4MyIsImFsbG93ZWRfYWN0aW9uX2lkcyI6WyI5Mjc2ZDk0ZS03NjNjLTRmMTgtOGQ0Yi0xMzEyNzVlNjY0YjQiLCI5YmJmMDQwNy01Mjc0LTRhMjYtOWY0OC05NjRmZjE3MzdhYzAiLCI0ZmM2ZGI0My1lYTA2LTRhZmMtYTY3MC0yY2E4ZDA0OTUwNzAiLCJiOWQzZmZkOS02MTkzLTQ4YmEtYTAyZC01ODM1YjFjMTIwYWQiLCIxZTQ1MzE3Ny0zMWRhLTQ3ZWMtYmZjZS03OTZmY2ViYzllNGIiXSwianRpIjoiNzNjNmMxMGItNTMwMy00OTYyLWIxNTktZDhjYzhiNmYxOTExIiwiaWF0IjoxNzc0NDUxMzg1LCJleHAiOjE3NzQ1Mzc3ODV9.6cmKUpQgqhKsx97wkXvh9qmKb-myXkg5ygX79Ajen4M
STARTED_TEMPLATE='{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiJjMzM1MWEwMi0wYmMyLTQ0NDktYmVlZC1kNTlkN2FjOTM3ZDAiLCJncm91cF9ydW5faWQiOiI4MDA4MTQ1My01ZWVjLTRjNjQtODYyOC04ZWRhNDMwZTlhYzEiLCJncm91cF9pZCI6ImFhMDg3ZDlhLTA1NDctNGQ3Ni1iZDUxLWY0ZWViMDAwNWU4MyIsImFsbG93ZWRfYWN0aW9uX2lkcyI6WyI5Mjc2ZDk0ZS03NjNjLTRmMTgtOGQ0Yi0xMzEyNzVlNjY0YjQiLCI5YmJmMDQwNy01Mjc0LTRhMjYtOWY0OC05NjRmZjE3MzdhYzAiLCI0ZmM2ZGI0My1lYTA2LTRhZmMtYTY3MC0yY2E4ZDA0OTUwNzAiLCJiOWQzZmZkOS02MTkzLTQ4YmEtYTAyZC01ODM1YjFjMTIwYWQiLCIxZTQ1MzE3Ny0zMWRhLTQ3ZWMtYmZjZS03OTZmY2ViYzllNGIiXSwianRpIjoiNzNjNmMxMGItNTMwMy00OTYyLWIxNTktZDhjYzhiNmYxOTExIiwiaWF0IjoxNzc0NDUxMzg1LCJleHAiOjE3NzQ1Mzc3ODV9.6cmKUpQgqhKsx97wkXvh9qmKb-myXkg5ygX79Ajen4M","event":"started","reporting_source":"bundle_callback"}'
FINISHED_SUCCESS_TEMPLATE='{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiJjMzM1MWEwMi0wYmMyLTQ0NDktYmVlZC1kNTlkN2FjOTM3ZDAiLCJncm91cF9ydW5faWQiOiI4MDA4MTQ1My01ZWVjLTRjNjQtODYyOC04ZWRhNDMwZTlhYzEiLCJncm91cF9pZCI6ImFhMDg3ZDlhLTA1NDctNGQ3Ni1iZDUxLWY0ZWViMDAwNWU4MyIsImFsbG93ZWRfYWN0aW9uX2lkcyI6WyI5Mjc2ZDk0ZS03NjNjLTRmMTgtOGQ0Yi0xMzEyNzVlNjY0YjQiLCI5YmJmMDQwNy01Mjc0LTRhMjYtOWY0OC05NjRmZjE3MzdhYzAiLCI0ZmM2ZGI0My1lYTA2LTRhZmMtYTY3MC0yY2E4ZDA0OTUwNzAiLCJiOWQzZmZkOS02MTkzLTQ4YmEtYTAyZC01ODM1YjFjMTIwYWQiLCIxZTQ1MzE3Ny0zMWRhLTQ3ZWMtYmZjZS03OTZmY2ViYzllNGIiXSwianRpIjoiNzNjNmMxMGItNTMwMy00OTYyLWIxNTktZDhjYzhiNmYxOTExIiwiaWF0IjoxNzc0NDUxMzg1LCJleHAiOjE3NzQ1Mzc3ODV9.6cmKUpQgqhKsx97wkXvh9qmKb-myXkg5ygX79Ajen4M","event":"finished","reporting_source":"bundle_callback","action_results":[],"non_executable_results":[{"action_id":"9276d94e-763c-4f18-8d4b-131275e664b4","support_tier":"review_required_bundle","profile_id":"s3_enforce_ssl_strict_deny","strategy_id":"s3_enforce_ssl_strict_deny","reason":"review_required_metadata_only","blocked_reasons":["Bucket policy preservation evidence is missing for merge-safe SSL enforcement."]},{"action_id":"9bbf0407-5274-4a26-9f48-964ff1737ac0","support_tier":"review_required_bundle","profile_id":"s3_enforce_ssl_strict_deny","strategy_id":"s3_enforce_ssl_strict_deny","reason":"review_required_metadata_only","blocked_reasons":["Bucket policy preservation evidence is missing for merge-safe SSL enforcement."]},{"action_id":"4fc6db43-ea06-4afc-a670-2ca8d0495070","support_tier":"review_required_bundle","profile_id":"s3_enforce_ssl_strict_deny","strategy_id":"s3_enforce_ssl_strict_deny","reason":"review_required_metadata_only","blocked_reasons":["Bucket policy preservation evidence is missing for merge-safe SSL enforcement."]},{"action_id":"b9d3ffd9-6193-48ba-a02d-5835b1c120ad","support_tier":"review_required_bundle","profile_id":"s3_enforce_ssl_strict_deny","strategy_id":"s3_enforce_ssl_strict_deny","reason":"review_required_metadata_only","blocked_reasons":["Bucket policy preservation evidence is missing for merge-safe SSL enforcement."]},{"action_id":"1e453177-31da-47ec-bfce-796fcebc9e4b","support_tier":"review_required_bundle","profile_id":"s3_enforce_ssl_strict_deny","strategy_id":"s3_enforce_ssl_strict_deny","reason":"review_required_metadata_only","blocked_reasons":["Bucket policy preservation evidence is missing for merge-safe SSL enforcement."]}]}'
FINISHED_FAILED_TEMPLATE='{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiJjMzM1MWEwMi0wYmMyLTQ0NDktYmVlZC1kNTlkN2FjOTM3ZDAiLCJncm91cF9ydW5faWQiOiI4MDA4MTQ1My01ZWVjLTRjNjQtODYyOC04ZWRhNDMwZTlhYzEiLCJncm91cF9pZCI6ImFhMDg3ZDlhLTA1NDctNGQ3Ni1iZDUxLWY0ZWViMDAwNWU4MyIsImFsbG93ZWRfYWN0aW9uX2lkcyI6WyI5Mjc2ZDk0ZS03NjNjLTRmMTgtOGQ0Yi0xMzEyNzVlNjY0YjQiLCI5YmJmMDQwNy01Mjc0LTRhMjYtOWY0OC05NjRmZjE3MzdhYzAiLCI0ZmM2ZGI0My1lYTA2LTRhZmMtYTY3MC0yY2E4ZDA0OTUwNzAiLCJiOWQzZmZkOS02MTkzLTQ4YmEtYTAyZC01ODM1YjFjMTIwYWQiLCIxZTQ1MzE3Ny0zMWRhLTQ3ZWMtYmZjZS03OTZmY2ViYzllNGIiXSwianRpIjoiNzNjNmMxMGItNTMwMy00OTYyLWIxNTktZDhjYzhiNmYxOTExIiwiaWF0IjoxNzc0NDUxMzg1LCJleHAiOjE3NzQ1Mzc3ODV9.6cmKUpQgqhKsx97wkXvh9qmKb-myXkg5ygX79Ajen4M","event":"finished","reporting_source":"bundle_callback","action_results":[],"non_executable_results":[{"action_id":"9276d94e-763c-4f18-8d4b-131275e664b4","support_tier":"review_required_bundle","profile_id":"s3_enforce_ssl_strict_deny","strategy_id":"s3_enforce_ssl_strict_deny","reason":"review_required_metadata_only","blocked_reasons":["Bucket policy preservation evidence is missing for merge-safe SSL enforcement."]},{"action_id":"9bbf0407-5274-4a26-9f48-964ff1737ac0","support_tier":"review_required_bundle","profile_id":"s3_enforce_ssl_strict_deny","strategy_id":"s3_enforce_ssl_strict_deny","reason":"review_required_metadata_only","blocked_reasons":["Bucket policy preservation evidence is missing for merge-safe SSL enforcement."]},{"action_id":"4fc6db43-ea06-4afc-a670-2ca8d0495070","support_tier":"review_required_bundle","profile_id":"s3_enforce_ssl_strict_deny","strategy_id":"s3_enforce_ssl_strict_deny","reason":"review_required_metadata_only","blocked_reasons":["Bucket policy preservation evidence is missing for merge-safe SSL enforcement."]},{"action_id":"b9d3ffd9-6193-48ba-a02d-5835b1c120ad","support_tier":"review_required_bundle","profile_id":"s3_enforce_ssl_strict_deny","strategy_id":"s3_enforce_ssl_strict_deny","reason":"review_required_metadata_only","blocked_reasons":["Bucket policy preservation evidence is missing for merge-safe SSL enforcement."]},{"action_id":"1e453177-31da-47ec-bfce-796fcebc9e4b","support_tier":"review_required_bundle","profile_id":"s3_enforce_ssl_strict_deny","strategy_id":"s3_enforce_ssl_strict_deny","reason":"review_required_metadata_only","blocked_reasons":["Bucket policy preservation evidence is missing for merge-safe SSL enforcement."]}]}'
REPLAY_DIR="./.bundle-callback-replay"
RUNNER="./run_actions.sh"
RUN_RC=1
FINISH_SENT=0

mkdir -p "$REPLAY_DIR"

iso_now() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

inject_timestamp() {
  local template_json="$1"
  local field_name="$2"
  local field_value="$3"
  python3 - "$template_json" "$field_name" "$field_value" <<'PY'
import json
import sys

payload = json.loads(sys.argv[1])
payload[str(sys.argv[2])] = str(sys.argv[3])
print(json.dumps(payload, separators=(",", ":")))
PY
}

post_payload() {
  local payload="$1"
  if [ -z "$REPORT_URL" ] || [ -z "$REPORT_TOKEN" ]; then
    return 1
  fi
  if command -v curl >/dev/null 2>&1; then
    local response_file http_code rc
    response_file=$(mktemp)
    http_code=$(curl -sS       --connect-timeout 5       --max-time 20       --retry 4       --retry-delay 2       --retry-all-errors       -o "$response_file"       -w "%{http_code}"       -X POST "$REPORT_URL"       -H "Content-Type: application/json"       -d "$payload")
    rc=$?
    if [ "$rc" -ne 0 ]; then
      rm -f "$response_file"
      return "$rc"
    fi
    rm -f "$response_file"
    case "$http_code" in
      2??)
        return 0
        ;;
    esac
    return 1
  fi
  return 1
}

persist_replay() {
  local suffix="$1"
  local payload="$2"
  local file="$REPLAY_DIR/${suffix}-$(date +%s).json"
  printf '%s\n' "$payload" > "$file"
}

emit_finished_callback() {
  local exit_code="$1"
  local finished_at payload
  if [ "$FINISH_SENT" -eq 1 ]; then
    return 0
  fi
  FINISH_SENT=1
  finished_at="$(iso_now)"
  if [ "$exit_code" -eq 0 ]; then
    payload="$(inject_timestamp "$FINISHED_SUCCESS_TEMPLATE" "finished_at" "$finished_at")"
  else
    payload="$(inject_timestamp "$FINISHED_FAILED_TEMPLATE" "finished_at" "$finished_at")"
  fi
  if ! post_payload "$payload"; then
    persist_replay "finished" "$payload"
  fi
}

handle_exit() {
  local exit_code="$1"
  emit_finished_callback "$exit_code"
  exit "$exit_code"
}

STARTED_AT="$(iso_now)"
START_PAYLOAD="$(inject_timestamp "$STARTED_TEMPLATE" "started_at" "$STARTED_AT")"
if ! post_payload "$START_PAYLOAD"; then
  persist_replay "started" "$START_PAYLOAD"
fi

trap 'handle_exit $?' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

chmod +x "$RUNNER"
"$RUNNER"
RUN_RC=$?
exit "$RUN_RC"
